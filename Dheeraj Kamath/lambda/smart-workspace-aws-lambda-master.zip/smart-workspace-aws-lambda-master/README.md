# Smart Workspace AWS Lambda

